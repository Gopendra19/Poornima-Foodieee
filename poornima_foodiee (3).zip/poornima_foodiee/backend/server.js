// server.js - fixed backend (products CRUD, orders POST & DELETE, reviews)
const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(cors());
app.use(express.json());

// Serve frontend statically (adjust path if your structure different)
app.use(express.static(path.join(__dirname, "../frontend")));

// Helpers
function readJSON(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (e) {
    return [];
  }
}
function writeJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

/* ---------- Files ---------- */
const PRODUCTS_FILE = "./products.json";
const ORDERS_FILE = "./orders.json";
const REVIEWS_FILE = "./reviews.json";

/* ---------- PRODUCTS ---------- */
app.get("/products", (req, res) => {
  const products = readJSON(PRODUCTS_FILE);
  res.json(products);
});

app.post("/products", (req, res) => {
  try {
    const products = readJSON(PRODUCTS_FILE);
    const p = req.body;
    p.id = p.id || Date.now();
    products.push(p);
    writeJSON(PRODUCTS_FILE, products);
    res.json({ success: true, product: p });
  } catch (err) {
    console.error("POST /products error", err);
    res.status(500).json({ error: "Could not save product" });
  }
});

app.put("/products/:id", (req, res) => {
  try {
    const id = String(req.params.id);
    const products = readJSON(PRODUCTS_FILE);
    const idx = products.findIndex(x => String(x.id) === id);
    if (idx === -1) return res.status(404).json({ error: "Not found" });
    products[idx] = { ...products[idx], ...req.body, id: products[idx].id };
    writeJSON(PRODUCTS_FILE, products);
    res.json({ success: true, product: products[idx] });
  } catch (err) {
    console.error("PUT /products/:id error", err);
    res.status(500).json({ error: "Could not update" });
  }
});

app.delete("/products/:id", (req, res) => {
  try {
    const id = String(req.params.id);
    let products = readJSON(PRODUCTS_FILE);
    products = products.filter(p => String(p.id) !== id);
    writeJSON(PRODUCTS_FILE, products);
    res.json({ success: true });
  } catch (err) {
    console.error("DELETE /products/:id", err);
    res.status(500).json({ error: "Could not delete" });
  }
});

/* ---------- ORDERS ---------- */
app.get("/orders", (req, res) => {
  const orders = readJSON(ORDERS_FILE);
  res.json(orders);
});

app.post("/orders", (req, res) => {
  try {
    const orders = readJSON(ORDERS_FILE);
    const o = req.body;
    const newOrder = {
      id: o.id || Date.now(),
      name: o.name || "Guest",
      mobile: o.mobile || "",
      address: o.address || "",
      payment: o.payment || "Unknown",
      items: o.items || [],
      total: o.total || 0,
      time: o.time || Date.now()
    };
    orders.push(newOrder);
    writeJSON(ORDERS_FILE, orders);
    res.json({ success: true, order: newOrder });
  } catch (err) {
    console.error("POST /orders error", err);
    res.status(500).json({ error: "Could not save order" });
  }
});

app.delete("/orders/:id", (req, res) => {
  try {
    const id = String(req.params.id);
    let orders = readJSON(ORDERS_FILE);
    const before = orders.length;
    orders = orders.filter(o => String(o.id) !== id);
    writeJSON(ORDERS_FILE, orders);
    res.json({ success: true, deleted: before - orders.length });
  } catch (err) {
    console.error("DELETE /orders/:id error", err);
    res.status(500).json({ error: "Delete failed" });
  }
});

/* ---------- REVIEWS ---------- */
app.get("/reviews", (req, res) => res.json(readJSON(REVIEWS_FILE)));

app.post("/reviews", (req, res) => {
  try {
    const reviews = readJSON(REVIEWS_FILE);
    const r = { id: Date.now(), ...req.body };
    reviews.push(r);
    writeJSON(REVIEWS_FILE, reviews);
    res.json({ success: true, review: r });
  } catch (err) {
    console.error("POST /reviews", err);
    res.status(500).json({ error: "Could not save review" });
  }
});

/* ---------- ADMIN LOGIN ---------- */
// NOTE: password kept as your earlier value "12345"
app.post("/admin/login", (req, res) => {
  const { password } = req.body;
  if (password === "12345") return res.json({ token: "superAdminToken" });
  return res.status(401).json({ message: "Wrong password" });
});

/* ---------- Serve frontend ---------- */
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
app.delete("/orders/:id", (req, res) => {
    const orderId = req.params.id;

    fs.readFile("orders.json", "utf8", (err, data) => {
        if (err) return res.status(500).json({ error: "Error reading orders file" });

        let orders = JSON.parse(data);
        let filtered = orders.filter(o => o.id != orderId);

        fs.writeFile("orders.json", JSON.stringify(filtered, null, 2), (err) => {
            if (err) return res.status(500).json({ error: "Error writing file" });
            res.json({ message: "Order deleted" });
        });
    });
});
app.delete("/products/:id", (req, res) => {
    const productId = req.params.id;

    fs.readFile("products.json", "utf8", (err, data) => {
        if (err) return res.status(500).json({ error: "Error reading product file" });

        let products = JSON.parse(data);
        let filtered = products.filter(p => p.id != productId);

        fs.writeFile("products.json", JSON.stringify(filtered, null, 2), (err) => {
            if (err) return res.status(500).json({ error: "Error writing file" });
            res.json({ message: "Product deleted successfully" });
        });
    });
});
